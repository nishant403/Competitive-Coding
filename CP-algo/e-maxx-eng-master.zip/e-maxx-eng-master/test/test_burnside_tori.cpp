#include <cassert>
#include <vector>
#include <set>
using namespace std;

#include "burnside_tori.h"

int main() {
    assert(solve(3, 2) == 13);
}
