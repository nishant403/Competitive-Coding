This folder is for storing small (say, less than 200kb) files in PNG, which should be used in the articles.
