e-maxx-eng
==========

[![Contributors](https://img.shields.io/github/contributors/e-maxx-eng/e-maxx-eng.svg)](https://github.com/e-maxx-eng/e-maxx-eng/graphs/contributors)
[![Pull Requests](https://img.shields.io/github/issues-pr/e-maxx-eng/e-maxx-eng.svg)](https://github.com/e-maxx-eng/e-maxx-eng/pulls)
[![Closed Pull Requests](https://img.shields.io/github/issues-pr-closed/e-maxx-eng/e-maxx-eng.svg)](https://github.com/e-maxx-eng/e-maxx-eng/pulls?q=is%3Apr+is%3Aclosed)
[![Build Status](https://travis-ci.org/e-maxx-eng/e-maxx-eng.svg?branch=master)](https://travis-ci.org/e-maxx-eng/e-maxx-eng)
[![Translation Progress](https://img.shields.io/badge/translation_progress-85.2%25-yellowgreen.svg)](https://github.com/e-maxx-eng/e-maxx-eng/wiki/Translation-Progress)

Translation of http://e-maxx.ru into English

Compiled pages are published at https://cp-algorithms.com/

Manual for contributors: https://cp-algorithms.com/contrib.html

Test-your-page form: https://cp-algorithms.com/test.php
